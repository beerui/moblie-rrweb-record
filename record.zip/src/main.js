import Vue from 'vue'
import App from './App.vue'
import router from './router'

// 引入Vant样式
import 'vant/lib/index.css'

// 引入Vant组件
import {
  Button,
  Cell,
  CellGroup,
  NavBar,
  Field,
  Dialog,
  Toast,
  Switch,
  Steps,
  Step,
  Form,
  Tag,
  NoticeBar,
  Icon,
  ActionSheet
} from 'vant'

// 引入rrweb-player样式
import 'rrweb-player/dist/style.css'

// 注册Vant组件
Vue.use(Button)
Vue.use(Cell)
Vue.use(CellGroup)
Vue.use(NavBar)
Vue.use(Field)
Vue.use(Dialog)
Vue.use(Toast)
Vue.use(Switch)
Vue.use(Steps)
Vue.use(Step)
Vue.use(Form)
Vue.use(Tag)
Vue.use(NoticeBar)
Vue.use(Icon)
Vue.use(ActionSheet)

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app') 