import { record } from 'rrweb'
import pako from 'pako'
import axios from 'axios'

class ScreenRecorder {
  constructor(options = {}) {
    this.events = []
    this.stopFn = null
    this.isRecording = false
    this.options = {
      // 默认配置
      uploadUrl: options.uploadUrl || '/api/record/upload',
      maxEvents: options.maxEvents || 1000,
      autoUpload: options.autoUpload !== false,
      compressData: options.compressData !== false,
      ...options
    }
  }

  // 等待页面完全加载
  async waitForPageLoad() {
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        // 额外等待一段时间确保所有异步内容加载完成
        setTimeout(resolve, 500)
      } else {
        window.addEventListener('load', () => {
          setTimeout(resolve, 500)
        })
      }
    })
  }

  // 开始录制
  async startRecording(metadata = {}) {
    if (this.isRecording) {
      console.warn('ScreenRecorder：录制已在进行中')
      return true
    }

    try {
      console.log('ScreenRecorder：等待页面加载...')
      // 等待页面完全加载
      await this.waitForPageLoad()
      console.log('ScreenRecorder：页面加载完成，初始化录制...')

      this.events = []
      this.isRecording = true

      // 添加元数据事件
      this.events.push({
        type: 'metadata',
        data: {
          ...metadata,
          startTime: Date.now(),
          userAgent: navigator.userAgent,
          url: window.location.href
        },
        timestamp: Date.now()
      })

      console.log('ScreenRecorder：添加了元数据事件，当前事件数量:', this.events.length)

      // 测试rrweb是否可用
      console.log('ScreenRecorder：检查rrweb record函数:', typeof record)
      
      // 开始rrweb录制
      this.stopFn = record({
        emit: (event) => {
          this.events.push(event)
          if (this.events.length <= 10 || this.events.length % 10 === 0) {
            console.log('ScreenRecorder：记录事件，类型:', event.type, '总数:', this.events.length)
          }
          
          // 如果事件数量过多，可以考虑分批上传
          if (this.events.length >= this.options.maxEvents) {
            this.uploadEvents()
          }
        },
        // 录制配置
        recordCanvas: true,
        collectFonts: true,
        plugins: [],
        // 添加一些额外配置确保兼容性
        checkoutEveryNms: 10 * 1000, // 每10秒做一次全量快照
        checkoutEveryNth: 200 // 每200个事件做一次全量快照
      })

      console.log('ScreenRecorder：rrweb录制已启动，stopFn:', !!this.stopFn)
      return true
    } catch (error) {
      console.error('ScreenRecorder：开始录制失败:', error)
      this.isRecording = false
      return false
    }
  }

  // 停止录制
  async stopRecording() {
    if (!this.isRecording) {
      console.warn('ScreenRecorder：当前没有进行录制')
      return null
    }

    try {
      console.log('ScreenRecorder：开始停止录制，当前事件数量:', this.events.length)
      
      if (this.stopFn) {
        this.stopFn()
        this.stopFn = null
        console.log('ScreenRecorder：rrweb录制已停止')
      }

      this.isRecording = false

      // 添加结束事件
      this.events.push({
        type: 'metadata',
        data: {
          endTime: Date.now(),
          totalEvents: this.events.length
        },
        timestamp: Date.now()
      })

      console.log('ScreenRecorder：录制已停止，共记录', this.events.length, '个事件')

      // 自动上传
      if (this.options.autoUpload) {
        console.log('ScreenRecorder：准备上传录制数据...')
        return await this.uploadEvents()
      }

      const recordData = this.getRecordData()
      console.log('ScreenRecorder：返回录制数据，事件数量:', recordData.events.length)
      return recordData
    } catch (error) {
      console.error('ScreenRecorder：停止录制失败:', error)
      return null
    }
  }

  // 获取录制数据
  getRecordData() {
    const recordData = {
      events: this.events,
      metadata: {
        recordTime: Date.now(),
        eventsCount: this.events.length,
        duration: this.events.length > 0 ? 
          this.events[this.events.length - 1].timestamp - this.events[0].timestamp : 0
      }
    }

    return recordData
  }

  // 压缩数据
  compressData(data) {
    try {
      const jsonString = JSON.stringify(data)
      const compressed = pako.gzip(jsonString)
      return {
        compressed: true,
        data: Array.from(compressed), // 转换为数组以便JSON序列化
        originalSize: jsonString.length,
        compressedSize: compressed.length
      }
    } catch (error) {
      console.error('数据压缩失败:', error)
      return {
        compressed: false,
        data: data,
        error: error.message
      }
    }
  }

  // 解压数据
  static decompressData(compressedData) {
    try {
      if (!compressedData.compressed) {
        return compressedData.data
      }

      const uint8Array = new Uint8Array(compressedData.data)
      const decompressed = pako.ungzip(uint8Array, { to: 'string' })
      return JSON.parse(decompressed)
    } catch (error) {
      console.error('数据解压失败:', error)
      return null
    }
  }

  // 上传录制数据
  async uploadEvents() {
    if (this.events.length === 0) {
      console.warn('ScreenRecorder：没有录制数据可上传')
      return null
    }

    try {
      const recordData = this.getRecordData()
      console.log('ScreenRecorder：准备上传数据，事件数量:', recordData.events.length)
      
      // 压缩数据
      const finalData = this.options.compressData ? 
        this.compressData(recordData) : recordData

      console.log('ScreenRecorder：数据处理完成，准备发送HTTP请求...')

      const response = await axios.post(this.options.uploadUrl, finalData, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30秒超时
      })

      console.log('ScreenRecorder：录制数据上传成功:', response.data)
      return recordData // 返回原始录制数据而不是响应数据
    } catch (error) {
      console.error('ScreenRecorder：上传录制数据失败:', error)
      // 上传失败时仍然返回录制数据，而不是抛出错误
      const recordData = this.getRecordData()
      console.log('ScreenRecorder：上传失败，但返回录制数据，事件数量:', recordData.events.length)
      return recordData
    }
  }

  // 清空录制数据
  clearEvents() {
    this.events = []
    console.log('录制数据已清空')
  }

  // 获取录制状态
  getRecordingStatus() {
    return {
      isRecording: this.isRecording,
      eventsCount: this.events.length
    }
  }

  // 添加自定义事件
  addCustomEvent(eventData) {
    if (!this.isRecording) {
      console.warn('未在录制状态，无法添加自定义事件')
      return
    }

    const customEvent = {
      type: 'custom',
      data: eventData,
      timestamp: Date.now()
    }

    this.events.push(customEvent)
    console.log('添加自定义事件:', eventData)
  }
}

export default ScreenRecorder 