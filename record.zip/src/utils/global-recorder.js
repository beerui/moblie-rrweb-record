import ScreenRecorder from './screen-record'
import pako from 'pako'

class GlobalRecorder {
  constructor() {
    this.recorder = null
    this.isRecording = false
    this.listeners = new Set()
    this.currentSession = null
    this.recordingStartTime = null
    this.timeoutTimer = null
    this.maxRecordingDuration = 3 * 60 * 1000 // 3分钟
    console.log('全局录制器：初始化完成')
  }

  // 获取单例实例
  static getInstance() {
    if (!GlobalRecorder.instance) {
      GlobalRecorder.instance = new GlobalRecorder()
    }
    return GlobalRecorder.instance
  }

  // 初始化录制器
  async initRecorder(options = {}) {
    if (!this.recorder) {
      console.log('全局录制器：创建新的ScreenRecorder实例...')
      this.recorder = new ScreenRecorder({
        uploadUrl: '/api/record/upload',
        autoUpload: false, // 改为false，避免上传失败影响录制数据返回
        compressData: true,
        ...options
      })
      console.log('全局录制器：ScreenRecorder实例创建完成')
    }
    return this.recorder
  }

  // 开始录制
  async startRecording(metadata = {}) {
    if (this.isRecording) {
      console.log('录制已在进行中')
      return true
    }

    try {
      console.log('全局录制器：开始初始化录制器...')
      await this.initRecorder()
      console.log('全局录制器：录制器初始化完成，开始录制...')
      
      const success = await this.recorder.startRecording({
        ...metadata,
        startTime: new Date().toISOString()
      })

      console.log('全局录制器：录制启动结果:', success)

      if (success) {
        this.isRecording = true
        this.recordingStartTime = Date.now()
        this.startTimeoutTimer()
        this.notifyListeners('started', metadata)
        console.log('全局录制器：录制已开始，状态设置为true')
        return true
      }
      console.warn('全局录制器：录制启动失败')
      return false
    } catch (error) {
      console.error('启动录制失败:', error)
      return false
    }
  }

  // 开始超时定时器
  startTimeoutTimer() {
    if (this.timeoutTimer) {
      clearTimeout(this.timeoutTimer)
    }
    
    this.timeoutTimer = setTimeout(() => {
      this.handleRecordingTimeout()
    }, this.maxRecordingDuration)
    
    console.log('全局录制器：超时定时器已启动，', this.maxRecordingDuration / 1000, '秒后超时')
  }

  // 处理录制超时
  async handleRecordingTimeout() {
    console.log('全局录制器：录制超时，自动停止录制')
    
    if (this.isRecording) {
      try {
        await this.stopRecording()
        this.notifyListeners('timeout', {
          duration: this.maxRecordingDuration,
          message: '录制时间超过3分钟，已自动停止'
        })
      } catch (error) {
        console.error('超时停止录制失败:', error)
      }
    }
  }

  // 清除超时定时器
  clearTimeoutTimer() {
    if (this.timeoutTimer) {
      clearTimeout(this.timeoutTimer)
      this.timeoutTimer = null
      console.log('全局录制器：超时定时器已清除')
    }
  }

  // 停止录制
  async stopRecording() {
    if (!this.isRecording) {
      console.log('没有正在进行的录制')
      return null
    }

    try {
      console.log('全局录制器：开始停止录制...')
      this.clearTimeoutTimer()
      const result = await this.recorder.stopRecording()
      console.log('全局录制器：录制停止结果:', result)
      console.log('全局录制器：事件数量:', result ? result.events?.length : 0)
      
      this.isRecording = false
      this.recordingStartTime = null
      this.notifyListeners('stopped', result)
      return result
    } catch (error) {
      console.error('停止录制失败:', error)
      this.isRecording = false
      this.recordingStartTime = null
      this.clearTimeoutTimer()
      this.notifyListeners('error', error)
      return null
    }
  }

  // 获取录制状态
  getRecordingStatus() {
    const status = {
      isRecording: this.isRecording,
      recorder: !!this.recorder,
      hasRecorder: !!this.recorder,
      startTime: this.recordingStartTime,
      duration: this.recordingStartTime ? Date.now() - this.recordingStartTime : 0,
      remainingTime: this.recordingStartTime ? 
        Math.max(0, this.maxRecordingDuration - (Date.now() - this.recordingStartTime)) : 0
    }
    
    if (this.recorder) {
      const recorderStatus = this.recorder.getRecordingStatus()
      status.recorderIsRecording = recorderStatus.isRecording
      status.eventsCount = recorderStatus.eventsCount
    }
    
    console.log('全局录制器状态:', status)
    return status
  }

  // 添加监听器
  addListener(listener) {
    this.listeners.add(listener)
  }

  // 移除监听器
  removeListener(listener) {
    this.listeners.delete(listener)
  }

  // 通知所有监听器
  notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      if (typeof listener === 'function') {
        listener(event, data)
      } else if (listener[event]) {
        listener[event](data)
      }
    })
  }

  // 添加录制事件
  addRecordEvent(event) {
    if (this.recorder && this.isRecording) {
      this.recorder.addCustomEvent(event)
    }
  }

  // 停止录制并处理数据
  async stopRecordingAndProcess(metadata = {}) {
    console.log('全局录制器：开始停止录制并处理数据')
    
    try {
      // 停止录制
      const recordingResult = await this.stopRecording()
      
      if (!recordingResult || !recordingResult.events || recordingResult.events.length === 0) {
        console.error('全局录制器：录制数据为空或无效')
        return {
          success: false,
          error: '录制数据为空',
          data: null
        }
      }

      // 处理录制数据
      const processedData = await this.processRecordingData(recordingResult, metadata)
      
      console.log('全局录制器：数据处理完成', {
        originalSize: this.getDataSize(recordingResult),
        processedSize: this.getDataSize(processedData.compressedData),
        compressionRatio: processedData.compressionRatio
      })

      return {
        success: true,
        data: processedData,
        recordingResult: recordingResult
      }
      
    } catch (error) {
      console.error('全局录制器：停止录制并处理数据失败:', error)
      return {
        success: false,
        error: error.message,
        data: null
      }
    }
  }

  // 处理录制数据
  async processRecordingData(recordingResult, metadata = {}) {
    console.log('全局录制器：开始处理录制数据')
    
    try {
      // 创建完整的录制数据包
      const fullData = {
        session: this.currentSession || {
          sessionId: 'session_' + Date.now(),
          startTime: Date.now()
        },
        metadata: {
          timestamp: Date.now(),
          userAgent: navigator.userAgent,
          url: window.location.href,
          recordingDuration: this.recordingStartTime ? Date.now() - this.recordingStartTime : 0,
          ...metadata
        },
        events: recordingResult.events,
        totalEvents: recordingResult.events.length
      }

      // 检查原始数据大小
      const originalDataStr = JSON.stringify(fullData)
      const originalSize = this.getDataSize(originalDataStr)
      console.log('全局录制器：原始数据大小:', this.formatBytes(originalSize))

      // 如果数据超过2MB，进行优化
      let finalData = fullData
      if (originalSize > 2 * 1024 * 1024) {
        console.log('全局录制器：数据超过2MB，开始优化')
        finalData = await this.optimizeRecordingData(fullData)
      }

      // 压缩数据
      const finalDataStr = JSON.stringify(finalData)
      const compressedData = pako.gzip(finalDataStr)
      const compressedSize = compressedData.length

      console.log('全局录制器：数据压缩完成', {
        originalSize: this.formatBytes(originalSize),
        finalSize: this.formatBytes(finalDataStr.length),
        compressedSize: this.formatBytes(compressedSize),
        compressionRatio: ((1 - compressedSize / originalSize) * 100).toFixed(2) + '%'
      })

      // 检查压缩后的大小
      if (compressedSize > 2 * 1024 * 1024) {
        throw new Error(`压缩后数据仍超过2MB限制 (${this.formatBytes(compressedSize)})`)
      }

      return {
        originalData: fullData,
        finalData: finalData,
        compressedData: compressedData,
        sizes: {
          original: originalSize,
          final: finalDataStr.length,
          compressed: compressedSize
        },
        compressionRatio: ((1 - compressedSize / originalSize) * 100).toFixed(2) + '%'
      }

    } catch (error) {
      console.error('全局录制器：处理录制数据失败:', error)
      throw error
    }
  }

  // 优化录制数据（如果超过2MB）
  async optimizeRecordingData(data) {
    console.log('全局录制器：开始优化录制数据')
    
    let optimizedEvents = [...data.events]
    let currentSize = this.getDataSize(JSON.stringify(data))

    // 优化策略1：移除冗余的鼠标移动事件
    if (currentSize > 2 * 1024 * 1024) {
      console.log('全局录制器：移除冗余鼠标移动事件')
      optimizedEvents = this.removeRedundantMouseMoves(optimizedEvents)
      currentSize = this.getDataSize(JSON.stringify({ ...data, events: optimizedEvents }))
      console.log('全局录制器：优化后大小:', this.formatBytes(currentSize))
    }

    // 优化策略2：简化事件数据结构
    if (currentSize > 2 * 1024 * 1024) {
      console.log('全局录制器：简化事件数据结构')
      optimizedEvents = this.simplifyEventData(optimizedEvents)
      currentSize = this.getDataSize(JSON.stringify({ ...data, events: optimizedEvents }))
      console.log('全局录制器：优化后大小:', this.formatBytes(currentSize))
    }

    // 优化策略3：事件采样（减少事件数量）
    if (currentSize > 2 * 1024 * 1024) {
      console.log('全局录制器：开始事件采样')
      const targetEventCount = Math.floor(optimizedEvents.length * 0.7) // 保留70%的事件
      optimizedEvents = this.sampleEvents(optimizedEvents, targetEventCount)
      currentSize = this.getDataSize(JSON.stringify({ ...data, events: optimizedEvents }))
      console.log('全局录制器：采样后大小:', this.formatBytes(currentSize))
    }

    // 优化策略4：如果还是太大，进一步减少事件
    if (currentSize > 2 * 1024 * 1024) {
      console.log('全局录制器：进一步减少事件数量')
      const targetEventCount = Math.floor(optimizedEvents.length * 0.5) // 保留50%的事件
      optimizedEvents = this.sampleEvents(optimizedEvents, targetEventCount)
      currentSize = this.getDataSize(JSON.stringify({ ...data, events: optimizedEvents }))
      console.log('全局录制器：最终大小:', this.formatBytes(currentSize))
    }

    const optimizedData = {
      ...data,
      events: optimizedEvents,
      totalEvents: optimizedEvents.length,
      optimization: {
        applied: true,
        originalEventCount: data.events.length,
        finalEventCount: optimizedEvents.length,
        reductionRatio: ((1 - optimizedEvents.length / data.events.length) * 100).toFixed(2) + '%'
      }
    }

    console.log('全局录制器：数据优化完成', optimizedData.optimization)
    return optimizedData
  }

  // 移除冗余的鼠标移动事件
  removeRedundantMouseMoves(events) {
    const filtered = []
    let lastMouseMove = null
    const mouseMoveThreshold = 50 // 保留每50ms的鼠标移动

    for (const event of events) {
      if (event.type === 3 && event.data && event.data.source === 1) { // 鼠标移动事件
        if (!lastMouseMove || event.timestamp - lastMouseMove.timestamp > mouseMoveThreshold) {
          filtered.push(event)
          lastMouseMove = event
        }
      } else {
        filtered.push(event)
      }
    }

    console.log('全局录制器：鼠标移动事件优化', {
      original: events.length,
      filtered: filtered.length,
      removed: events.length - filtered.length
    })

    return filtered
  }

  // 简化事件数据结构
  simplifyEventData(events) {
    return events.map(event => {
      const simplified = {
        type: event.type,
        timestamp: event.timestamp
      }

      // 只保留关键数据，移除不必要的属性
      if (event.data) {
        if (event.type === 3) { // 增量快照事件
          simplified.data = {
            source: event.data.source,
            type: event.data.type
          }
          // 只保留关键的增量数据
          if (event.data.texts) simplified.data.texts = event.data.texts
          if (event.data.attributes) simplified.data.attributes = event.data.attributes
          if (event.data.removes) simplified.data.removes = event.data.removes
          if (event.data.adds) simplified.data.adds = event.data.adds
        } else {
          simplified.data = event.data
        }
      }

      return simplified
    })
  }

  // 事件采样
  sampleEvents(events, targetCount) {
    if (events.length <= targetCount) return events

    const step = events.length / targetCount
    const sampled = []
    
    // 总是保留第一个和最后一个事件
    sampled.push(events[0])
    
    for (let i = 1; i < targetCount - 1; i++) {
      const index = Math.floor(i * step)
      sampled.push(events[index])
    }
    
    // 保留最后一个事件
    sampled.push(events[events.length - 1])

    console.log('全局录制器：事件采样完成', {
      original: events.length,
      target: targetCount,
      actual: sampled.length
    })

    return sampled
  }

  // 上传录制数据
  async uploadRecordingData(processedData, uploadUrl = '/api/recording/upload') {
    console.log('全局录制器：开始上传录制数据')
    
    try {
      // 创建上传数据包
      const uploadData = {
        sessionId: this.currentSession?.sessionId || 'session_' + Date.now(),
        timestamp: Date.now(),
        metadata: processedData.finalData.metadata,
        dataSize: processedData.sizes.compressed,
        compressionRatio: processedData.compressionRatio,
        eventCount: processedData.finalData.totalEvents,
        // 压缩数据转换为base64以便传输
        compressedData: this.arrayBufferToBase64(processedData.compressedData)
      }

      console.log('全局录制器：准备上传数据', {
        sessionId: uploadData.sessionId,
        dataSize: this.formatBytes(uploadData.dataSize),
        eventCount: uploadData.eventCount
      })

      // 模拟API上传（实际项目中替换为真实的API调用）
      const response = await this.mockApiUpload(uploadData)
      
      console.log('全局录制器：数据上传成功', response)
      return response

    } catch (error) {
      console.error('全局录制器：数据上传失败:', error)
      // 上传失败时仍返回处理好的数据，而不是抛出错误
      return {
        success: false,
        error: error.message,
        uploadedAt: Date.now(),
        retryable: true
      }
    }
  }

  // 模拟API上传（实际项目中替换为真实的API调用）
  async mockApiUpload(uploadData) {
    console.log('全局录制器：模拟API上传，数据大小:', this.formatBytes(uploadData.dataSize))
    
    // 模拟网络延迟
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000))
    
    // 模拟上传结果
    return {
      success: true,
      uploadId: 'upload_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
      uploadedAt: Date.now(),
      size: uploadData.dataSize,
      message: '录制数据上传成功'
    }
  }

  // 获取数据大小（字节）
  getDataSize(data) {
    if (typeof data === 'string') {
      return new Blob([data]).size
    } else if (data instanceof ArrayBuffer) {
      return data.byteLength
    } else if (data instanceof Uint8Array) {
      return data.length
    } else {
      return new Blob([JSON.stringify(data)]).size
    }
  }

  // 格式化字节数
  formatBytes(bytes) {
    if (bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  // ArrayBuffer转Base64
  arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer)
    let binary = ''
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i])
    }
    return btoa(binary)
  }
}

export default GlobalRecorder 